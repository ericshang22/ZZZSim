/************************************LIFEFORM CLASS***********************/
//Model of MVC Model
//Describes the various attributes of the lifeforms
//Depending on class, they will have different levels of hostility
//Store images from controller

package summative;

import javax.swing.ImageIcon;
import java.awt.image.BufferedImage;

abstract class Lifeforms //abstract class for all of the lifeforms
{
	/*************************Data Fields*********************************/
	protected int maxhealth, health, movementSpeed, positionX, positionY, hunger = 0, poisonTurns = 0;// y is column, x is row
	protected boolean isUser = false;
	protected String name;
	protected BufferedImage image;
	protected ImageIcon icon;

	/*************************Methods*********************************/
	public boolean getStatus()		//whether the lifeform is alive
	{
		if(health > 0)
			return true;
		else
			return false;
	}
	public ImageIcon getIcon()		//return the icon
	{
		icon = new ImageIcon(image);
		return icon;
	}

	public boolean proximity(Lifeforms x)  //whether or not there is a lifeform beside another
	{
		if(Math.abs(x.getPositionX() - this.getPositionX()) == 1)
			return true;
		if(Math.abs(x.getPositionY() - this.getPositionY()) == 1)
			return true;
		return false;
	}

	//generate new x coordinates
	public int generateX()
	{
		return ((int) (Math.random()* 4 - 2)) + this.getPositionX();
	}

	public int generateY()
	{
		return ((int) (Math.random()* 4 - 2)) + this.getPositionY();
	}

	//accessors and setters
	public int getPositionX()
	{
		return positionX;
	}

	public int getPositionY()
	{
		return positionY;
	}

	public void setPositionX(int x)
	{
		positionX = x;
	}

	public void setPositionY(int y)
	{
		positionY = y;
	}

	public int getHealth()
	{
		return health;
	}
	public int getMaxHealth()
	{
		return maxhealth;
	}

	public boolean isAUser()
	{
		return isUser;
	}

	public abstract String getName();  

	public void setImage(BufferedImage image) 
	{
		this.image = image;
	}

	public BufferedImage getImage() 
	{
		return image;

	}

	public void setHealth(int x) 
	{
		health += x;

	}

	public void setPoisonTurns(int x)
	{
		if(poisonTurns + x >= 3)
			this.poisonTurns = 3;
		else if(poisonTurns + x < 0)
			this.poisonTurns = 0;
		else
			this.poisonTurns += x;
	}

	public int getPoisonTurns()
	{
		return poisonTurns;
	}
}

/*************************************Allies************************************************************/

class User extends Lifeforms		//the class for the user
{
	int damage, hungerDepletionSpeed, hungerDepletionAmount, hunger;

	public User()		//constructor
	{
		maxhealth = 300;
		health = 300;  //100 is a heart, 10 is a user hit
		movementSpeed = 500;  //delay is 500 ms
		damage = 20;  //amount of hp per click
		hunger = 100;  //hunger bar
		hungerDepletionSpeed = 1000; //rate of depletion
		hungerDepletionAmount = 2;
		isUser = true;
		positionX = 0;
		positionY = 0;
		poisonTurns = 0;
	}

	public void setHealth(int value) 
	{
		health += value;
	}

	public int getDamage()
	{
		return damage;
	}

	public int gethungerDepletionAmount()
	{
		return hungerDepletionAmount;
	}

	public String getName() 
	{
		return "User";
	}

	public int getHunger()
	{
		return hunger;
	}

	public void setHunger(int hunger)
	{
		if(hunger + this.hunger >= 100)
			this.hunger = 100;
		else
			this.hunger += hunger;
	}

	public void setDamage(int damage)
	{
		this.damage += damage;
	}

	public void setHungerDepletionAmount(int hungerDepletionAmount)
	{
		this.hungerDepletionAmount += hungerDepletionAmount;
	}

}

class Zombie extends Lifeforms		//the zombie class
{
	int storedHealth, damageBoost, depletion, damage;
	User player;		//attached to the player

	public Zombie(User p) 
	{
		maxhealth = 100;
		health = 100;
		movementSpeed = 50;
		storedHealth = 100;
		damageBoost = 10;
		depletion = 2;
		damage = 10;

		//provides the boosts to the players damage and hungerdepletion
		player = p;
		player.setDamage(damageBoost);
		player.setHungerDepletionAmount(depletion);
	}

	public void die()		//when the zombie dies
	{
		if(this.getStatus() == false)		//check the status
		{
			//change the various attributes of the user object
			player.setDamage(-damageBoost);
			player.setHungerDepletionAmount(-depletion);
			player.setHealth(storedHealth);
		}
	}

	public String getName()
	{
		return "Zombie";
	}

	public int getDamage()
	{
		return damage;
	}

	public void setStoredHealth(int storedHealth)
	{
		this.storedHealth = storedHealth;
	}
}

/*************************************NEUTRAL************************************************************/

abstract class Neutral extends Lifeforms		//the neutral abstract class
{
	//provides hunger and can reproduce
	int hungerGained, reproductionChance;

	public abstract boolean reproduce();

	public int getHungerGained()
	{
		return hungerGained;
	}

	public void setHungerGained(int hungerGained)
	{
		this.hungerGained = hungerGained;
	}

	public void die(Lifeforms l)
	{
		//gives the hunger to the user if killed
		if(this.getStatus() == false && l.isAUser() == true)
			l.hunger += hungerGained;
	}
}

class Rats extends Neutral		//rat class
{
	public Rats()
	{
		//various attributes
		maxhealth = 50;
		health = 50;
		movementSpeed = 400;
		reproductionChance = health/5;
		hungerGained = 10;
	}

	public boolean reproduce()		//method to decide if it reproduces
	{
		int chance = (int)(Math.random() * 10000 + 1);
		return chance < reproductionChance;
	}

	public String getName()
	{
		return "Rat";
	}
}

class Dog extends Neutral		//dog class
{
	int damage;

	public Dog()
	{
		//various attributes
		maxhealth = 80;
		health = 80;
		movementSpeed = 600;
		damage = 20;
		reproductionChance = health/5;
		hungerGained = 20;
	}

	public boolean reproduce()  //chance to reproduce
	{
		int chance = (int)(Math.random() * 10000 + 1);
		return chance < reproductionChance;
	}

	public String getName()
	{
		return "Dog";
	}

	public int getDamage()
	{
		return damage;
	}
}

/******************************************ENEMIES***********************************************/

abstract class Enemies extends Lifeforms		//abstract class for all enemies
{
	protected int damage;

	public int getDamage()
	{
		return damage;
	}
}

class Police extends Enemies
{
	int infectionChance;

	public Police()
	{
		//the police's attributes
		maxhealth = 80;
		health = 80;
		infectionChance = 50;
		damage = 50;
	}

	public boolean infected()   //chance of infections
	{
		int chance = (int)(Math.random() * 100 + 1);

		return chance < infectionChance;
	}

	public String getName()
	{
		return "Police";
	}

	public void setInfectionChance(int infectionChance)
	{
		this.infectionChance = infectionChance;
	}
}



