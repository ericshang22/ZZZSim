/*******************************MENUGUI CLASS *****************************************/
//View of the MVC Model
//Provides the main menu
//Shows the instructions and can create the game window

package summative;
import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.*; 
import java.io.*;
import java.awt.image.BufferedImage;

public class MenuGUI extends JFrame implements MouseListener
{
	DrawArea board;
	Graphics g;
	BufferedImage menu, instructions;
	boolean menuDisplayed = true;

	public MenuGUI()
	{
		try 
		{     
			//importing images
			menu = ImageIO.read(new File("menu.png"));
			System.out.println("d");
			instructions = ImageIO.read(new File("C:\\\\Users\\\\jason\\\\OneDrive\\\\Documents\\\\ICS\\\\ICS Summative\\\\instructions.png"));	     
		} 
		catch (IOException ex) 
		{

		}
		// 1... Create/initialize components        
		addMouseListener(this);

		// 2... Create content pane, set layout
		JPanel content = new JPanel ();        // Create a content pane
		content.setLayout (new BorderLayout ()); // Use BorderLayout for panel


		board = new DrawArea (1200, 600);
		board.setFocusable(true);

		// 3... Add the components to the input area.    
		content.add (board, "Center"); // Output area

		// 4... Set this window's attributes.
		setContentPane (content);
		pack ();
		setTitle ("ZZZSIM");
		setSize (1200, 600);
		setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo (null);           // Center window.

	}

	class DrawArea extends JPanel 
	{
		public DrawArea(int width, int height) 
		{
			this.setPreferredSize(new Dimension(width, height)); // size
		}

		public void paintComponent(Graphics g) 
		{
			if(menuDisplayed) //if menu displayed then show menu
				g.drawImage(menu,0,0,this);
			else
				g.drawImage(instructions, 0,0, this); //otherwise shoe the instructions
		}
	}




	public void mouseClicked(MouseEvent e) {
		int y = e.getY(); //coordinates of mouse click
		int x = e.getX();

		if(menuDisplayed) //if on menu screen
		{
			try {
				if(x >= 640 && x <= 730 && y >= 410 && y <= 730) //if clicked the HOW TO PLAY text
					menuDisplayed = false;  //show instructions
				if(x >= 440 && x <= 550 && y >= 410 && y <= 730) //if clicked on START
				{
					this.dispose(); //close current window
					ZZZSim scene = new ZZZSim(); //new ZZZombie GUI
					scene.setVisible(true);
					scene.setResizable(false);
				}
				repaint();
			}
			catch(Exception e1) {
			}
		}
		else //if on instructions screen
		{
			try {
				if(x >= 25 && x <= 415 && y >= 495 && y <= 535) // if clicked on BACK TO MAIN MENU text
					menuDisplayed = true; //show menu
				repaint();
			}
			catch(Exception e1) {
			}
		}
		repaint();
	}




	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) { 
	}

	public void mousePressed(MouseEvent e) { 
	}

	public void mouseReleased(MouseEvent e) { 
	}

	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String[] args)  //main method
	{
		MenuGUI window = new MenuGUI();
		window.setVisible(true);
		window.setResizable(false);
	}




}
