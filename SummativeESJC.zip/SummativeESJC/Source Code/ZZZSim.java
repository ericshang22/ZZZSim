/************************************ZZZOMBIEGUI CLASS***********************/
//View of MVC Model
//Provides the GUI pane for the player to see
//Shows the images

package summative;
import java.awt.*;

import javax.swing.*;
import java.awt.event.*; // Needed for ActionListener
import java.util.ArrayList;
import javax.swing.JOptionPane;

class ZZZSim extends JFrame implements MouseListener, KeyListener, ActionListener 
{
	/*************************Data Fields*********************************/
	Environment environment;		//create the new environment
	Timer t,f,h;		//the timers
	DrawArea board;
	Graphics g;
	ArrayList <Integer> list;		//the arraylist for lifeforms to flash red

	/*************************Constructor*********************************/
	public ZZZSim()
	{
		environment = new Environment();
		// 1... Create/initialize components        
		addMouseListener(this);
		addKeyListener(this);
		setFocusable(true);

		// 2... Create content pane, set layout
		JPanel content = new JPanel ();        // Create a content pane
		content.setLayout (new BorderLayout ()); // Use BorderLayout for panel
		content.addKeyListener(this);
		content.setFocusable(true);

		Movement moveEnvironment = new Movement(environment); // ActionListener
		t = new Timer(1000, moveEnvironment); // set up timer
		t.start(); // start simulation

		board = new DrawArea (1200, 600);
		board.addKeyListener(this);
		board.setFocusable(true);

		// 3... Add the components to the input area.    
		content.add (board, "Center"); // Output area

		// 4... Set this window's attributes.
		setContentPane (content);
		pack ();
		setTitle ("ZZZombie");
		setSize (1200, 600);
		setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo (null);           // Center window.

	}

	class DrawArea extends JPanel 
	{
		public DrawArea(int width, int height) 
		{
			this.setPreferredSize(new Dimension(width, height)); // size
		}

		public void paintComponent(Graphics g) 
		{
			environment.show(g);		//show the environment and lifeforms
		}
	}

	class Movement implements ActionListener 
	{
		private Environment environment;

		public Movement(Environment e) {
			environment = e;
		}

		public void actionPerformed(ActionEvent e) {

			//perform the adjustments to the environment
			environment.advance();
			repaint();

			//if the user is dead, stop the timers
			if(!environment.scan() || environment.winCondition())
			{
				t.stop();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				dispose();
				MenuGUI window = new MenuGUI();
				window.setVisible(true);
				window.setResizable(false);

				environment = new Environment();
			}


			list = environment.interact();

			//loop through the list and adjust the pictures of the interacted lifeforms
			ActionListener flash = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					for(int x = 0; x < list.size()/2; x++)
					{
						environment.flash(list.get(x*2), list.get(x*2+1),true,false); 
						repaint();
					}

				}
			};

			//start the timer to show the flash
			h = new Timer(200,flash);
			h.setRepeats(false);
			h.start(); 
			repaint();
		}
	}

	public void keyPressed(KeyEvent e) {//key pressed for the movement of the user

		if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D)
		{
			environment.move(1);
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
			environment.move(4);
		}
		if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
			environment.move(2);
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
			environment.move(3);
		}


		repaint();
	}


	@Override
	public void keyReleased(KeyEvent e) {  
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	public void mouseClicked(MouseEvent e) {//when the mouse is clicked

		//get the row and column numbers for the array
		int row = (e.getY() - 350) / 58 ;
		int col = e.getX() / 55;
		if(e.getButton() == MouseEvent.BUTTON1)		//if left click
		{
			try {

				//ensure that the row and col are in bounds
				if(row >= 0 && row <= 3 && col >= 0 && col <= 21 ){

					//hit the lifeform
					environment.hit(row,col);
					repaint();

					//flash the list of interacted arrays
					ActionListener flash = new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							environment.flash(row, col,false,true);
							repaint();
						}
					};
					f = new Timer(200,flash);
					f.setRepeats(false);
					f.start();
					environment.flash(row, col,true,true);
					repaint();
				}


			}
			catch(Exception e1) {

			}
		}
		else if(e.getButton() == MouseEvent.BUTTON3)		//if right click popup message
		{
			try {
				if(row >= 0 && row <= 3 && col >= 0 && col <= 21 ){
					JOptionPane.showMessageDialog(this,
							environment.stats(row,col),"Information about this tile",JOptionPane.INFORMATION_MESSAGE,environment.returnicon(row, col));  
				}
			}
			catch(Exception e1) {

			}
		}
	}


	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) { 
	}

	public void mousePressed(MouseEvent e) { 
	}

	public void mouseReleased(MouseEvent e) { 
	}

	public void actionPerformed(ActionEvent e) {

	}
}