/*******************************ENVIRONMENT CLASS *****************************************/
//Controller of MVC Model
//Reads input from the GUI and applies changes to the 2d array
//Manages all of the images
//Reads the status and controls the movement of the lifeforms
//Implements the interactions

package summative;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Environment
{
	/*************************Data Fields*********************************/
	Lifeforms[][] landscape;		//the 2d array to store the lifeforms
	int hunger, userHealth, ratNum, dogNum, policeNum, zombieNum; 
	char type;
	User p;

	//the various images for the background, lifeforms, and user stats
	BufferedImage background, backgroundIcon,  gameover, win, heartPic1, heartPic2, heartPic3, heartPic4, heartPic1poisoned, heartPic2poisoned, heartPic3poisoned, heartPic4poisoned, hungerBar;
	BufferedImage ratPic, ratbloody, ratpoisoned, rat1, rat2, rat1bloody, rat1poisoned, rat2bloody, rat2poisoned, ratbaby;
	BufferedImage dogPic, dogbloody, dogpoisoned, dog1, dog2, dog1bloody, dog1poisoned, dog2bloody, dog2poisoned, dogbaby;
	BufferedImage policePic, police1, police2, policebloody, police1bloody, police2bloody, policepoisoned, police1poisoned, police2poisoned, policebaby;
	BufferedImage playerPic, userbloody, userpoisoned;
	BufferedImage zombiePic, zombiebloody, zombiepoisoned;
	BufferedImage water, poison;
	ImageIcon Bicon, Wicon, Picon;

	/*************************Constructor*********************************/
	public Environment()
	{
		try 
		{         
			//importing all of the photos
			background = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\CityBackground1.png"));

			ratPic = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\rat.png"));
			ratbloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\ratbloody.png"));
			ratpoisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\ratpoisoned.png"));
			rat1 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\rat1.png"));
			rat1bloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\rat1bloody.png"));
			rat1poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\rat1poisoned.png"));
			rat2 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\rat2.png"));
			rat2bloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\rat2bloody.png"));
			rat2poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\rat2poisoned.png"));
			ratbaby = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\ratbaby.png"));

			dogPic = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dog.png"));
			dogbloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dogbloody.png"));
			dogpoisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dogpoisoned.png"));
			dog1 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dog1.png"));
			dog1bloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dog1bloody.png"));
			dog1poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dog1poisoned.png"));
			dog2 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dog2.png"));
			dog2bloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dog2bloody.png"));
			dog2poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dog2poisoned.png"));
			dogbaby = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\dogbaby.png"));

			policePic = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\police.png"));
			policebloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\policebloody.png"));
			policepoisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\policepoisoned.png"));
			police1 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\police1.png"));
			police1bloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\police1bloody.png"));
			police1poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\police1poisoned.png"));
			police2 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\police2.png"));
			police2bloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\police2bloody.png"));
			police2poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\police2poisoned.png"));
			
			playerPic = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\User.png"));
			userbloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\userbloody.png"));
			userpoisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\userpoisoned.png"));

			zombiePic = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\zombie.png"));
			zombiebloody = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\zombiebloody.png"));
			zombiepoisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\zombiepoisoned.png"));

			gameover = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\gameover.png"));
			win = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\win.png"));
			heartPic1 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic1.png"));
			heartPic2 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic2.png"));
			heartPic3 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic3.png"));
			heartPic4 = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic4.png"));
			hungerBar = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\hungerBar.png")); 
			backgroundIcon = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\icon.png")); 

			heartPic1poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic1poisoned.png")); 
			heartPic2poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic2poisoned.png")); 
			heartPic3poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic3poisoned.png")); 
			heartPic4poisoned = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\heartPic4poisoned.png")); 

			water = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\water.png")); 
			poison = ImageIO.read(new File("C:\\Users\\jason\\OneDrive\\Documents\\ICS\\ICS Summative\\poison.png")); 
		} 
		catch (IOException ex) 
		{

		}

		//Initialization of icon
		Bicon = new ImageIcon(backgroundIcon);
		Wicon = new ImageIcon(water);
		Picon = new ImageIcon(poison);

		//Creation of the user
		landscape = new Lifeforms [4][22];
		p = new User();
		p.setImage(playerPic);

		//Fill the 2d array with the different life forms
		do
		{
			for(int r = 0; r < landscape.length; r ++)
			{
				for(int c = 0; c < landscape[r].length; c++)
				{
					if(landscape[r][c] == null)
					{
						this.scan();

						//spawn the lifeforms at random
						int chance = (int)(Math.random() * 100 + 1);

						if(chance > 0 && chance <= 5 && ratNum < 9)
						{
							Rats rat = new Rats();
							rat.setImage(ratPic);
							landscape[r][c] = rat;
							rat.setPositionX(c);
							rat.setPositionY(r);
						}

						if(chance > 5 && chance <= 8 && dogNum < 6)
						{
							Dog dog = new Dog();
							dog.setImage(dogPic);
							landscape[r][c] = dog;
							dog.setPositionX(c);
							dog.setPositionY(r);
						}

						else if(chance > 8 && chance <= 10 && policeNum < 5)
						{
							Police police = new Police();
							police.setImage(policePic);
							landscape[r][c] = police;
							police.setPositionX(c);
							police.setPositionY(r);
						}
					}

				}
			}
		}while(ratNum < 9 || dogNum < 6 || policeNum < 5);	//until there are a certain number of lifeforms

		//Place the user into the array
		landscape[0][0] = p;
		p.setPositionX(0);
		p.setPositionY(0);
	}

	/*************************Methods*********************************/
	public void show (Graphics g)		//method to display the graphics
	{
		if(p.getStatus())		//only if the user is alive
		{
			g.drawImage(background, 0, 0, null);		//draw the background
			if(p.getPoisonTurns() == 0)		//regular hearts
			{
				int start = 0;
				for(int i = 0; i < p.getHealth()/100; i++)
				{
					g.drawImage(heartPic1, start * 90, 0, null);	//draw full hears
					start ++;
				}

				int leftover = p.getHealth() - start * 100;
				if(leftover >= 75)
					g.drawImage(heartPic2, start * 90, 0, null);		//3/4 quarter hearts
				else if(leftover >= 50)
					g.drawImage(heartPic3, start * 90, 0, null);		//half hearts
				else if (leftover > 25 || ((p.getHealth()/100) == 0 && leftover < 25))
					g.drawImage(heartPic4, start * 90, 0, null);		//quarter hearts
			}
			else		//poison hearts
			{
				int start = 0;
				for(int i = 0; i < p.getHealth()/100; i++)
				{
					g.drawImage(heartPic1poisoned, start * 90, 0, null);
					start ++;
				}

				int leftover = p.getHealth() - start * 100;
				if(leftover >= 75)
					g.drawImage(heartPic2poisoned, start * 90, 0, null);
				else if(leftover >= 50)
					g.drawImage(heartPic3poisoned, start * 90, 0, null);
				else if (leftover > 25 || ((p.getHealth()/100) == 0 && leftover < 25))
					g.drawImage(heartPic4poisoned, start * 90, 0, null);
			}

			//Hunger Bar
			g.setColor(Color.WHITE);
			g.fillRect(1000, 20, 180, 50);

			if(p.getHunger() < 30)		//Danger level
				g.setColor(Color.RED);
			else if (p.getHunger() > 90)		//Regeneration level
				g.setColor(Color.GREEN);
			else
				g.setColor(Color.ORANGE);		//Regular
			g.fillRect(1000, 20, (int)(180 - 1.8 * (100 - p.getHunger())), 50);
			g.drawImage(hungerBar, 950, -5, null);

			//Loop through array and draw the images
			for(int r = 0; r < landscape.length; r ++)
			{
				for(int c = 0; c < landscape[r].length; c ++)
				{
					if(landscape[r][c] != null)
					{
						if(landscape[r][c].getStatus())
							g.drawImage(landscape[r][c].getImage(), c * 55 , r * 64 + 300, null);
						else
							this.die(r,c);		//if the lifeform dies
					}

				}
			}
		}

		else		//if user is dead, draw the game over screen
			g.drawImage(gameover, 0, 0, null);

		if(this.winCondition())		//win screen
			g.drawImage(win, 0, 0, null);

	}

	public void advance()		//method to move the game forward
	{ 
		this.refresh(landscape);		//refresh the landscape

		if(p.getHunger() == 0)  //if there is no hunger left, health decreases by 10
			p.setHealth(-10);
		else
			p.setHunger(-p.gethungerDepletionAmount());  //hunger goes down by 1 

		if(p.getHunger() > 90)		//if hunger is greater than 90, user begins to regenerate health
			p.setHealth(5);

		//create a new array for the next generation
		Lifeforms[][] nextGen = new Lifeforms[4][22];

		//loop through the array
		for(int r = 0; r < landscape.length; r ++)
		{
			for(int c = 0; c < landscape[0].length; c++)
			{   
				if(landscape[r][c] != null)
				{
					//change their image if the lifeform are poisoned
					if(landscape[r][c].getPoisonTurns() > 0)
						poisonChecker(r,c, false);

					//movement for the other lifeforms
					if(landscape[r][c].isAUser() == false)
					{
						int nextX, nextY;
						boolean test = false;

						do
						{
							//generate the next values
							nextX = landscape[r][c].generateX();
							nextY = landscape[r][c].generateY();

							//if the value is within the bounds of the array
							if((nextX >= 0 && nextX <= 21) && (nextY >= 0 && nextY <= 3) && (landscape[nextY][nextX] != p))
								test = true;

							try 
							{
								// if there is nothing in the next spot
								if(nextGen[nextY][nextX] != null)
								{
									test = false;
								}
							}
							catch(ArrayIndexOutOfBoundsException e)
							{

							}

						}while(test == false);

						//move the lifeform into the nextGen array
						nextGen[nextY][nextX] = landscape[r][c];
						nextGen[nextY][nextX].setPositionX(nextX);
						nextGen[nextY][nextX].setPositionY(nextY);
					}

					//if there is no life form, copy the cell over
					else
						nextGen[r][c] = landscape[r][c];
				}    
			}
		}
		//replace the old landscape with nextGen
		landscape = nextGen;
		refresh(landscape);

	}

	public void refresh()		//method to refresh the images
	{
		//loop through the array
		for(int r = 0; r < landscape.length; r ++)
		{
			for(int c = 0; c < landscape[0].length; c++)
			{ 
				if (landscape[r][c] != null) 
				{
					//check for poison and health
					if(landscape[r][c].getPoisonTurns() == 0)
						bloodyChecker(r,c, false);
					else
						poisonChecker(r,c, false);
				}
			}
		}


	}

	public void refresh(Lifeforms[][] arr)	//method to refresh the images
	{
		//loop through the array
		for(int r = 0; r < arr.length; r ++)
		{
			for(int c = 0; c < arr[0].length; c++)
			{ 
				if(arr[r][c] != null)
				{
					//check for poison and health
					if(arr[r][c].getPoisonTurns() == 0)
						bloodyChecker(r,c, false);
					else
						poisonChecker(r,c, false);
				}
			}
		}



	}


	public void move(int d)		//method for the user to move
	{
		int newY = 0;
		int newX = 0;
		boolean moves = false;

		//if the lifeform is a user
		try{
			if(p.isAUser())
			{
				newX = p.getPositionX();
				newY = p.getPositionY();
				moves = true;
			}
		}
		catch(NullPointerException e )
		{
			moves = false;
		}

		//change the the coordinates of the user
		if(d == 2 && p.getPositionY() > 0 && moves && landscape[newY-1][newX] == null)
		{
			newY -= 1 ;
		}
		else if(d == 3 && p.getPositionY() < 3 && moves && landscape[newY+1][newX] == null)
		{
			newY += 1 ;
		}
		else if(d == 4 && p.getPositionX() > 0 && moves && landscape[newY][newX-1] == null)
		{
			newX -= 1 ;
		}
		else if(d == 1 && p.getPositionX() < 21 && moves && landscape[newY][newX+1] == null)
		{
			newX += 1 ;
		}

		//if the user can enter the next square
		if(landscape[newY][newX] == null)
		{
			//make the previous box null
			landscape[p.getPositionY()][p.getPositionX()] = null;

			//move the user to new cell
			landscape[newY][newX] = p;

			p.setPositionX(newX);
			p.setPositionY(newY);
		}

	}
	public void hit(int r, int c)
	{

		//if user is not close enough to the lifeform
		if(!((Math.abs(p.getPositionX() - c) == 1 || p.getPositionX() - c == 0 ) && (Math.abs(p.getPositionY() - r) == 1 || p.getPositionY() - r == 0 )))
			return;

		if(landscape[r][c] == null || landscape[r][c].isAUser())  //if there is no life form there or is the user
			return;

		landscape[r][c].setHealth(-p.getDamage());  //every click does 10 damage

		this.scan();		//scan to update the number of lifeforms

	}

	public void die(int r, int c)		//method for the when a lifeform dies
	{
		try
		{
			p.setHunger(((Neutral) landscape[r][c]).getHungerGained());  //if it is a user
			landscape[r][c] = null;  //make the cell empty
			return;
		}
		catch (ClassCastException e)
		{

		}

		try
		{
			if(((Police) landscape[r][c]).infected())  //if infected
			{
				Zombie zombie = new Zombie(p);  
				zombie.setImage(zombiePic);
				landscape[r][c] = zombie;
				zombie.setPositionX(c);
				zombie.setPositionY(r);  //initialize a new zombie
			}
			else
				landscape[r][c] = null;

			return;
		}

		catch (ClassCastException e)
		{

		}

		try
		{
			//when the zombie dies, give the user the appropriate boosts
			((Zombie) landscape[r][c]).die();
			landscape[r][c] = null;
			return;
		}

		catch (ClassCastException e)
		{

		}

	}

	public ArrayList<Integer> interact()		//method for the interactions of the lifeforms
	{
		//create a new arraylist to store the attacked lifeforms
		ArrayList<Integer> list = new ArrayList<Integer>();

		for(int r = 0; r < landscape.length; r++)
		{
			for(int c = 0; c < landscape[r].length; c++)
			{
				if(landscape[r][c] != null)
				{
					//if the lifeform is in the water, set the poison turns to zero
					if(r == 1 && (c >=5 && c <=8))
						landscape[r][c].setPoisonTurns(-10);

					//if the lifeform is poisoned, they take damage
					if(landscape[r][c].getPoisonTurns() > 0)
					{
						landscape[r][c].setPoisonTurns(-1);
						landscape[r][c].setHealth(-10);
						list.add(r);
						list.add(c);

						//if the lifeform dies to the poison, user will not receive the benefits
						if(!landscape[r][c].getStatus())
						{
							if (landscape[r][c].getName().equals("Dog"))
								((Neutral) landscape[r][c]).setHungerGained(0);
							else if(landscape[r][c].getName().equals("Police"))
								((Police) landscape[r][c]).setInfectionChance(0);
							else if(landscape[r][c].getName().equals("Rat"))
								((Neutral) landscape[r][c]).setHungerGained(0);
							else if(landscape[r][c].getName().equals("Zombie"))
								((Zombie)landscape[r][c]).setStoredHealth(0);
						}
					}

					//if the lifeform is in the poison, set turns to 3
					if((r == 3 && ((c>=8 && c<=11)))|| (r == 1 && (c>=18 && c <=21)))
						landscape[r][c].setPoisonTurns(3);
				}

				//if there is a lifeform in the cell
				if(landscape[r][c] != null && !landscape[r][c].isAUser())
				{
					//if there is a lifeform beside it
					if(find(r,c) != null)
					{
						/****************Reproduction function************/
						//if they are the same class
						if(landscape[r][c].getName().equals(find(r,c).getName()) && (landscape[r][c].getName().equals("Dog") || landscape[r][c].getName().equals("Rat")))
						{
							//find an empty cell
							int emptyR = (int)(Math.random() * 4 - 2);
							int emptyC = (int)(Math.random() * 4 - 2);    

							try 
							{
								//check if the box is open
								if(landscape[r + emptyR][c + emptyC] == null)
								{
									//create the new object depending on the classes
									if(landscape[r][c].getName().equals("Rat") && ratNum < 5)
									{
										Rats rat = new Rats();
										rat.setImage(ratbaby);
										landscape[r + emptyR][c + emptyC] = rat;
										rat.setPositionX(c + emptyC);
										rat.setPositionY(r + emptyR);
									}
									else if(landscape[r][c].getName().equals("Dog") && dogNum < 5)
									{
										Dog dog = new Dog();
										dog.setImage(dogbaby);
										landscape[r + emptyR][c + emptyC] = dog;
										dog.setPositionX(c + emptyC);
										dog.setPositionY(r + emptyR);
									}
								}
							}
							catch(IndexOutOfBoundsException e)
							{

							}

						} 
						/**********Between different lifeform interactions*************/
						else if (landscape[r][c].getName().equals("Dog"))
						{
							//dog can harm any lifeform
							find(r,c).setHealth(-((Dog) landscape[r][c]).getDamage());

							if((find(r,c).getName().equals("Rat") || find(r,c).getName().equals("Dog")) && !find(r,c).getStatus())
								((Neutral)find(r,c)).setHungerGained(0);

							else if(find(r,c).getName().equals("Police") && !find(r,c).getStatus())
								((Police)find(r,c)).setInfectionChance(0);

							else if(find(r,c).getName().equals("Zombie") && !find(r,c).getStatus())
								((Zombie)find(r,c)).setStoredHealth(0);

							list.add(find(r,c).getPositionY());
							list.add(find(r,c).getPositionX()); 

						}

						else if (landscape[r][c].getName().equals("Police"))
						{
							//police can only harm dogs and the user
							if((find(r,c).isAUser() || find(r,c).getName().equals("Dog")) && !find(r,c).getName().equals("Police"))
							{
								find(r,c).setHealth(-((Police) landscape[r][c]).getDamage());
								list.add(find(r,c).getPositionY());
								list.add(find(r,c).getPositionX());
							}

							if(find(r,c).getName().equals("Dog") && !find(r,c).getStatus())
								((Neutral)find(r,c)).setHungerGained(0);
						}

						else if (landscape[r][c].getName().equals("Zombie"))
						{
							//the zombie can attack any lifeform that is not a zombie or the user
							if(!find(r,c).isAUser() && !find(r,c).getName().equals("Zombie"))
							{
								find(r,c).setHealth(-((Zombie) landscape[r][c]).getDamage());
								list.add(find(r,c).getPositionY());
								list.add(find(r,c).getPositionX());
							}
							
							if((find(r,c).getName().equals("Rat") || find(r,c).getName().equals("Dog"))  && !find(r,c).getStatus())
								((Neutral)find(r,c)).setHungerGained(0);

						}
					}
				}
			}
		}
		//return the interacted lifeforms
		return list;
	}

	public Lifeforms find(int r, int c)		//search around a position and return a lifeform, if any
	{
		for(int i = 0; i < 8; i ++)
		{
			try  //check the different edges once
			{
				if (i == 0 && landscape [r][c - 1] != null)  //check the 8 different edges
					return landscape [r][c - 1];
				else if (i == 1 && landscape [r - 1][c] != null)
					return landscape [r -1][c];
				else if (i == 2 && landscape [r - 1][c + 1] != null)
					return landscape [r - 1][c + 1];
				else if (i == 3 && landscape [r - 1][c - 1] != null)
					return landscape [r - 1][c - 1];
				else if (i == 4 && landscape [r][c + 1] != null)
					return landscape [r][c + 1];
				else if (i == 5 && landscape [r + 1][c - 1] != null)
					return landscape [r + 1][c - 1];
				else if (i == 6 && landscape [r + 1][c] != null)
					return landscape [r + 1][c - 1];
				else if (i == 7 && landscape [r][c + 1] != null)
					return landscape [r][c + 1];
			}
			catch (ArrayIndexOutOfBoundsException e)  //catch the exception
			{

			}
		}
		//return null if there isnt one
		return null;
	}

	public boolean scan()		//scan the array and update the number of lifeforms
	{
		dogNum = 0;
		ratNum = 0; 
		policeNum = 0;
		zombieNum = 0;

		for (int r = 0; r < landscape.length; r++)
		{
			for (int c = 0; c < landscape[r].length; c++)
			{
				if(landscape[r][c] != null)
				{
					if(landscape[r][c].getPoisonTurns() == 0)
						bloodyChecker (r,c, true);
					else
						poisonChecker(r,c, true);

				}

			}
		}  
		return p.getStatus();
	}

	public void flash(int r, int c,boolean b, boolean s)		//method for the flash of red when lifeforms are attacked
	{
		if(s)
		{
			if(!((Math.abs(p.getPositionX() - c) == 1 || p.getPositionX() - c == 0 ) && (Math.abs(p.getPositionY() - r) == 1 || p.getPositionY() - r == 0 )))
				return;

			if(landscape[r][c] == null || landscape[r][c].isAUser())  //if there is no life form there or is the user
				return;
		}
		if(landscape[r][c]!= null)
		{
			//display the appropriate picture depending on the health level of the lifeform
			if(b) {
				if (landscape[r][c].getName().equals("Dog"))
				{
					if(landscape[r][c].getHealth() < 30)
						landscape[r][c].setImage(dog2bloody);

					else if(landscape[r][c].getHealth() < 60)
						landscape[r][c].setImage(dog1bloody);

					else
						landscape[r][c].setImage(dogbloody);
				}
				else if(landscape[r][c].getName().equals("Police"))
				{
					if(landscape[r][c].getHealth() < 30)
						landscape[r][c].setImage(police2bloody);

					else if(landscape[r][c].getHealth() < 50)
						landscape[r][c].setImage(police1bloody);
					else
						landscape[r][c].setImage(policebloody);
				}
				else if(landscape[r][c].getName().equals("Rat"))
				{
					if(landscape[r][c].getHealth() < 30)
						landscape[r][c].setImage(rat2bloody);

					else if(landscape[r][c].getHealth() < 40)
						landscape[r][c].setImage(rat1bloody);
					else
						landscape[r][c].setImage(ratbloody);
				}
				else if(landscape[r][c].getName().equals("Zombie"))
				{
					landscape[r][c].setImage(zombiebloody);
				}
				else if(landscape[r][c].getName().equals("User"))
				{
					landscape[r][c].setImage(userbloody);
				}
			}
			else {
				if(landscape[r][c].getPoisonTurns() > 0)
					poisonChecker(r,c, false);
				else
					bloodyChecker(r,c, false);
			}
		}
	}

	public void poisonChecker(int r, int c, boolean type)		//check for poison and display correct picture
	{
		if(landscape[r][c].getName().equals("Dog"))
		{
			if(type)
				dogNum++;

			if(landscape[r][c].getHealth() < 30)
				landscape[r][c].setImage(dog2poisoned);

			else if(landscape[r][c].getHealth() < 60)
				landscape[r][c].setImage(dog1poisoned);

			else
				landscape[r][c].setImage(dogpoisoned);

		}
		else if (landscape[r][c].getName().equals("Rat"))
		{
			if(type)
				ratNum++;

			if(landscape[r][c].getHealth() < 30)
				landscape[r][c].setImage(rat2poisoned);

			else if(landscape[r][c].getHealth() < 40)
				landscape[r][c].setImage(rat1poisoned);
			else
				landscape[r][c].setImage(ratpoisoned);
		}
		else if (landscape[r][c].getName().equals("Police"))
		{
			if(type)
				policeNum++;

			if(landscape[r][c].getHealth() < 30)
				landscape[r][c].setImage(police2poisoned);

			else if(landscape[r][c].getHealth() < 50)
				landscape[r][c].setImage(police1poisoned);

			else
				landscape[r][c].setImage(policepoisoned);
		}
		else if(landscape[r][c].getName().equals("Zombie"))
		{
			if(type)
				zombieNum++;

			landscape[r][c].setImage(zombiepoisoned);
		}
		else if(landscape[r][c].getName().equals("User"))
			landscape[r][c].setImage(userpoisoned);
	}

	public void bloodyChecker(int r, int c, boolean type)		//method to display the correct health state
	{
		if(landscape[r][c].getName().equals("Dog"))
		{
			if(type)
				dogNum++;

			if(landscape[r][c].getHealth() < 30)
				landscape[r][c].setImage(dog2);

			else if(landscape[r][c].getHealth() < 60)
				landscape[r][c].setImage(dog1);

			else
				landscape[r][c].setImage(dogPic);

		}
		else if (landscape[r][c].getName().equals("Rat"))
		{
			if(type)
				ratNum++;

			if(landscape[r][c].getHealth() < 30)
				landscape[r][c].setImage(rat2);

			else if(landscape[r][c].getHealth() < 40)
				landscape[r][c].setImage(rat1);

			else
				landscape[r][c].setImage(ratPic);
		}
		else if (landscape[r][c].getName().equals("Police"))
		{
			if(type)
				policeNum++;

			if(landscape[r][c].getHealth() < 30)
				landscape[r][c].setImage(police2);

			else if(landscape[r][c].getHealth() < 50)
				landscape[r][c].setImage(police1);
			else
				landscape[r][c].setImage(policePic);
		}
		else if(landscape[r][c].getName().equals("Zombie"))
		{
			if(type)
				zombieNum++;

			if(landscape[r][c].getHealth() < 40)
				landscape[r][c].setImage(zombiebloody);

			else
				landscape[r][c].setImage(zombiePic);
		}
		if(p.getPoisonTurns() > 0)
			p.setImage(userpoisoned);
		else if(p.getHealth() < 100)
			p.setImage(userbloody);
		else
			p.setImage(playerPic);
	}

	public String stats(int r, int c)		//method for the data fields of the lifeform
	{
		if(landscape[r][c] != null)		//if there is a life form
		{
			//check and display status
			String status;
			if(landscape[r][c].getPoisonTurns() > 0)
				status = " POISONED ";
			else if ( landscape[r][c].getHealth() < landscape[r][c].getMaxHealth())
				status = " DAMAGED ";
			else if (landscape[r][c].getHealth() > landscape[r][c].getMaxHealth())
				status = " VERY HEALTHY ";
			else
				status = " HEALTHY ";

			return landscape[r][c].getName().toUpperCase() + "\nHP: " + landscape[r][c].getHealth() + " / " + landscape[r][c].getMaxHealth()+ "\nSTATUS:" + status;
		}

		else if(((r == 3 && (c == 8 || c ==9 || c==10 ||c ==11)) || ((r == 1 && (c == 18 || c == 19 || c==20 ||c == 21)))))
			return "DANGER: POISONOUS";
		else if (((r == 1 && (c == 5 || c ==6 || c==7 ||c ==8))))
			return "WATER: ANTIDOTE FOR POISON";

		else
			return "NOTHING HERE";
	}
	public ImageIcon returnicon(int r, int c)		//method to return the icon image
	{
		if(landscape[r][c] != null)
		{
			return landscape[r][c].getIcon();
		}

		else if(((r == 3 && (c == 8 || c ==9 || c==10 ||c ==11)) || ((r == 1 && (c == 18 || c == 19 || c==20 ||c == 21)))))
			return Picon;
		else if (((r == 1 && (c == 5 || c ==6 || c==7 ||c ==8))))
			return Wicon;

		else
			return Bicon;
	}

	public boolean winCondition() // checks for win
	{
		boolean r = true;
		for(int i = 0; i < landscape.length; i ++) //loops through array
		{
			for(int j = 0; j< landscape[0].length; j++)
			{
				if(landscape[i][j] != null)
				{
					if(landscape[i][j].getName().equals("Dog")||landscape[i][j].getName().equals("Rat") || landscape[i][j].getName().equals("Police")) //if there is a non zombie life form game not won yet
					{
						r = false;
					}
				}
			}
		}
		return r;
	}

}
